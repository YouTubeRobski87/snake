import test from 'node:test';
import assert from 'node:assert/strict';

import {
  DIRECTIONS,
  createInitialState,
  placeFood,
  setDirection,
  step
} from '../src/snake-logic.js';

test('snake moves one cell in current direction', () => {
  const state = createInitialState({ width: 8, height: 8, random: () => 0 });
  const next = step(state, () => 0);

  assert.deepEqual(next.snake[0], { x: state.snake[0].x + 1, y: state.snake[0].y });
  assert.equal(next.snake.length, state.snake.length);
  assert.equal(next.score, 0);
  assert.equal(next.status, 'running');
});

test('snake collides with wall and ends the game', () => {
  const state = {
    width: 5,
    height: 5,
    snake: [
      { x: 4, y: 2 },
      { x: 3, y: 2 },
      { x: 2, y: 2 }
    ],
    direction: DIRECTIONS.RIGHT,
    food: { x: 0, y: 0 },
    score: 0,
    status: 'running',
    canChangeDirection: true
  };

  const next = step(state, () => 0);
  assert.equal(next.status, 'game-over');
});

test('snake collides with itself and ends the game', () => {
  const state = {
    width: 6,
    height: 6,
    snake: [
      { x: 2, y: 2 },
      { x: 2, y: 3 },
      { x: 1, y: 3 },
      { x: 1, y: 2 }
    ],
    direction: DIRECTIONS.DOWN,
    food: { x: 5, y: 5 },
    score: 0,
    status: 'running',
    canChangeDirection: true
  };

  const next = step(state, () => 0);
  assert.equal(next.status, 'game-over');
});

test('snake grows and score increments when food is eaten', () => {
  const state = {
    width: 6,
    height: 6,
    snake: [
      { x: 2, y: 2 },
      { x: 1, y: 2 },
      { x: 0, y: 2 }
    ],
    direction: DIRECTIONS.RIGHT,
    food: { x: 3, y: 2 },
    score: 0,
    status: 'running',
    canChangeDirection: true
  };

  const next = step(state, () => 0);
  assert.equal(next.snake.length, 4);
  assert.equal(next.score, 1);
  assert.notDeepEqual(next.food, { x: 3, y: 2 });
  assert.equal(next.status, 'running');
});

test('food placement never overlaps snake', () => {
  const snake = [
    { x: 0, y: 0 },
    { x: 1, y: 0 },
    { x: 2, y: 0 }
  ];

  const food = placeFood(4, 4, snake, () => 0);
  assert.ok(food);

  const overlaps = snake.some(
    (segment) => segment.x === food.x && segment.y === food.y
  );

  assert.equal(overlaps, false);
});

test('direction cannot reverse in one move', () => {
  const state = createInitialState({ width: 8, height: 8, random: () => 0 });
  const attempted = setDirection(state, DIRECTIONS.LEFT);

  assert.equal(attempted.direction, DIRECTIONS.RIGHT);
});
