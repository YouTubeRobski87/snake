import { createReadStream, existsSync, statSync } from 'node:fs';
import { createServer } from 'node:http';
import { extname, join, normalize } from 'node:path';
import { fileURLToPath } from 'node:url';

const root = fileURLToPath(new URL('..', import.meta.url));
const port = process.env.PORT ? Number(process.env.PORT) : 5173;

const contentTypes = {
  '.css': 'text/css; charset=utf-8',
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml; charset=utf-8'
};

function send404(response) {
  response.writeHead(404, { 'Content-Type': 'text/plain; charset=utf-8' });
  response.end('Not found');
}

function resolvePath(urlPath) {
  const requestPath = decodeURIComponent(urlPath.split('?')[0]);
  const safePath = normalize(requestPath).replace(/^([.][.][/\\])+/, '');
  const absolute = join(root, safePath === '/' ? 'index.html' : safePath);

  if (!absolute.startsWith(root)) {
    return null;
  }

  if (existsSync(absolute) && statSync(absolute).isDirectory()) {
    const nestedIndex = join(absolute, 'index.html');
    if (existsSync(nestedIndex)) {
      return nestedIndex;
    }
  }

  return absolute;
}

createServer((request, response) => {
  const path = resolvePath(request.url ?? '/');

  if (!path || !existsSync(path) || statSync(path).isDirectory()) {
    send404(response);
    return;
  }

  const contentType = contentTypes[extname(path)] ?? 'application/octet-stream';
  response.writeHead(200, { 'Content-Type': contentType });
  createReadStream(path).pipe(response);
}).listen(port, () => {
  console.log(`Snake dev server running at http://localhost:${port}`);
});
