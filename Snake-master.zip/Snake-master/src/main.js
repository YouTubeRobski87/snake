import {
  DIRECTIONS,
  createInitialState,
  restartGame,
  setDirection,
  step
} from './snake-logic.js';

const TICK_MS = 140;

const gridElement = document.querySelector('#grid');
const scoreElement = document.querySelector('#score');
const statusElement = document.querySelector('#status');
const pauseButton = document.querySelector('#pause');
const restartButton = document.querySelector('#restart');
const controlButtons = document.querySelectorAll('.controls [data-direction]');

let state = createInitialState();
let intervalId = null;
const cells = [];

function toIndex(x, y) {
  return y * state.width + x;
}

function buildGrid() {
  gridElement.style.gridTemplateColumns = `repeat(${state.width}, 1fr)`;
  gridElement.replaceChildren();
  cells.length = 0;

  const total = state.width * state.height;
  for (let i = 0; i < total; i += 1) {
    const cell = document.createElement('div');
    cell.className = 'cell';
    gridElement.append(cell);
    cells.push(cell);
  }
}

function updateStatusText() {
  if (state.status === 'game-over') {
    statusElement.textContent = 'Game over';
    return;
  }

  if (state.status === 'paused') {
    statusElement.textContent = 'Paused';
    return;
  }

  statusElement.textContent = 'Running';
}

function render() {
  for (const cell of cells) {
    cell.className = 'cell';
  }

  for (const segment of state.snake) {
    const index = toIndex(segment.x, segment.y);
    const cell = cells[index];
    if (cell) {
      cell.classList.add('snake');
    }
  }

  if (state.food) {
    const index = toIndex(state.food.x, state.food.y);
    const cell = cells[index];
    if (cell) {
      cell.classList.add('food');
    }
  }

  scoreElement.textContent = String(state.score);
  pauseButton.textContent = state.status === 'paused' ? 'Resume' : 'Pause';
  updateStatusText();
}

function tick() {
  if (state.status !== 'running') {
    return;
  }

  state = step(state);
  render();
}

function startLoop() {
  if (intervalId !== null) {
    clearInterval(intervalId);
  }
  intervalId = setInterval(tick, TICK_MS);
}

function handleDirection(direction) {
  state = setDirection(state, direction);
  render();
}

function togglePause() {
  if (state.status === 'game-over') {
    return;
  }

  state = {
    ...state,
    status: state.status === 'paused' ? 'running' : 'paused'
  };
  render();
}

function resetGame() {
  state = restartGame(state);
  buildGrid();
  render();
}

const keyToDirection = {
  ArrowUp: DIRECTIONS.UP,
  ArrowDown: DIRECTIONS.DOWN,
  ArrowLeft: DIRECTIONS.LEFT,
  ArrowRight: DIRECTIONS.RIGHT,
  w: DIRECTIONS.UP,
  a: DIRECTIONS.LEFT,
  s: DIRECTIONS.DOWN,
  d: DIRECTIONS.RIGHT,
  W: DIRECTIONS.UP,
  A: DIRECTIONS.LEFT,
  S: DIRECTIONS.DOWN,
  D: DIRECTIONS.RIGHT
};

document.addEventListener('keydown', (event) => {
  const direction = keyToDirection[event.key];
  if (direction) {
    event.preventDefault();
    handleDirection(direction);
    return;
  }

  if (event.key === ' ') {
    event.preventDefault();
    togglePause();
  }
});

for (const button of controlButtons) {
  button.addEventListener('click', () => {
    handleDirection(button.dataset.direction);
  });
}

pauseButton.addEventListener('click', togglePause);
restartButton.addEventListener('click', resetGame);

buildGrid();
render();
startLoop();
