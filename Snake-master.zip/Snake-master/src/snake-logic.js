export const DIRECTIONS = Object.freeze({
  UP: 'UP',
  DOWN: 'DOWN',
  LEFT: 'LEFT',
  RIGHT: 'RIGHT'
});

const DIRECTION_OFFSETS = Object.freeze({
  [DIRECTIONS.UP]: { x: 0, y: -1 },
  [DIRECTIONS.DOWN]: { x: 0, y: 1 },
  [DIRECTIONS.LEFT]: { x: -1, y: 0 },
  [DIRECTIONS.RIGHT]: { x: 1, y: 0 }
});

const OPPOSITES = Object.freeze({
  [DIRECTIONS.UP]: DIRECTIONS.DOWN,
  [DIRECTIONS.DOWN]: DIRECTIONS.UP,
  [DIRECTIONS.LEFT]: DIRECTIONS.RIGHT,
  [DIRECTIONS.RIGHT]: DIRECTIONS.LEFT
});

export function createInitialState(options = {}) {
  const width = options.width ?? 20;
  const height = options.height ?? 20;
  const random = options.random ?? Math.random;

  const head = {
    x: Math.floor(width / 2),
    y: Math.floor(height / 2)
  };

  const snake = [
    head,
    { x: head.x - 1, y: head.y },
    { x: head.x - 2, y: head.y }
  ];

  return {
    width,
    height,
    snake,
    direction: DIRECTIONS.RIGHT,
    food: placeFood(width, height, snake, random),
    score: 0,
    status: 'running',
    canChangeDirection: true
  };
}

export function placeFood(width, height, snake, random = Math.random) {
  const occupied = new Set(snake.map((segment) => `${segment.x},${segment.y}`));
  const freeCells = [];

  for (let y = 0; y < height; y += 1) {
    for (let x = 0; x < width; x += 1) {
      const key = `${x},${y}`;
      if (!occupied.has(key)) {
        freeCells.push({ x, y });
      }
    }
  }

  if (freeCells.length === 0) {
    return null;
  }

  const index = Math.floor(random() * freeCells.length);
  return freeCells[index];
}

export function setDirection(state, nextDirection) {
  if (state.status !== 'running') {
    return state;
  }

  if (!DIRECTION_OFFSETS[nextDirection]) {
    return state;
  }

  if (!state.canChangeDirection) {
    return state;
  }

  if (OPPOSITES[state.direction] === nextDirection) {
    return state;
  }

  return {
    ...state,
    direction: nextDirection,
    canChangeDirection: false
  };
}

export function step(state, random = Math.random) {
  if (state.status !== 'running') {
    return state;
  }

  const offset = DIRECTION_OFFSETS[state.direction];
  const currentHead = state.snake[0];
  const nextHead = {
    x: currentHead.x + offset.x,
    y: currentHead.y + offset.y
  };

  if (
    nextHead.x < 0 ||
    nextHead.x >= state.width ||
    nextHead.y < 0 ||
    nextHead.y >= state.height
  ) {
    return {
      ...state,
      status: 'game-over',
      canChangeDirection: true
    };
  }

  const willEat =
    state.food !== null &&
    nextHead.x === state.food.x &&
    nextHead.y === state.food.y;

  const expandedSnake = [nextHead, ...state.snake];
  const nextSnake = willEat ? expandedSnake : expandedSnake.slice(0, -1);

  const hitsSelf = nextSnake
    .slice(1)
    .some((segment) => segment.x === nextHead.x && segment.y === nextHead.y);

  if (hitsSelf) {
    return {
      ...state,
      snake: nextSnake,
      status: 'game-over',
      canChangeDirection: true
    };
  }

  if (!willEat) {
    return {
      ...state,
      snake: nextSnake,
      canChangeDirection: true
    };
  }

  const food = placeFood(state.width, state.height, nextSnake, random);

  return {
    ...state,
    snake: nextSnake,
    food,
    score: state.score + 1,
    status: food === null ? 'game-over' : 'running',
    canChangeDirection: true
  };
}

export function restartGame(state, options = {}) {
  return createInitialState({
    width: options.width ?? state.width,
    height: options.height ?? state.height,
    random: options.random
  });
}
